package com.cursos.SpringRestFull;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestFullApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestFullApplication.class, args);
	}

}
