package com.cursos.SpringRestFull;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestFullApplicationTests {

	@Test
	void contextLoads() {
	}

}
